document.getElementById('fetchNews').addEventListener('click', async () => {
    // Menonaktifkan tombol setelah diklik
    toggleFetchNewsButton(false);
    
    const url = document.getElementById('newsLink').value;
    if (!url) {
        alert('Silakan masukkan URL berita.');
        toggleFetchNewsButton(true); // Mengaktifkan kembali tombol jika URL tidak valid
        return;
    }
    console.log('Fetching news from:', url); 
    const corsProxy = 'https://api.codetabs.com/v1/proxy?quest=';

    // Menampilkan pesan "Sedang Membaca Berita.."
    const loadingMessage = document.createElement('p');
    loadingMessage.id = 'loadingMessage';
    document.body.appendChild(loadingMessage);

    // Menampilkan domain utama di atas headline
    const domain = new URL(url).hostname;
    document.getElementById('newsDomain').innerText = domain;

    // Menambahkan notifikasi sebelum memulai proses pengambilan berita
    document.getElementById('chatResponse').innerText = 'Reading the news...';

    try {
        const response = await fetch(corsProxy + encodeURIComponent(url));
        console.log('Response status:', response.status); 
        if (!response.ok) {
            throw new Error('Network response was not ok: ' + response.statusText);
        }
        const text = await response.text();
        console.log('Fetched text:', text); 
        const parser = new DOMParser();
        const doc = parser.parseFromString(text, 'text/html');

        const title = doc.querySelector('title');
        const body = doc.querySelector('body');

        if (title && body) {
            // Menghapus elemen-elemen yang tidak diinginkan
            body.querySelectorAll('script, style, [type="application/ld+json"]').forEach(el => el.remove());

            // Mengambil teks dari elemen <p>
            const paragraphs = body.querySelectorAll('p');
            let bodyText = '';
            paragraphs.forEach(p => {
                bodyText += p.textContent + ' ';
            });
            bodyText = bodyText.replace(/\n+/g, ' ').trim(); // Menghapus semua baris baru
            bodyText = bodyText.replace(/\s+/g, ' '); // Menghapus spasi ganda

            document.getElementById('newsTitle').innerText = title.textContent;
            document.getElementById('newsBody').innerText = bodyText;
            console.log('News title:', title.textContent); 
            console.log('News body:', bodyText); 

            // Memasukkan semua data ke dalam <textarea id="userInput">
            const userInput = document.getElementById('userInput');
            const fullText = `News Domain: ${domain}\n\nNews Title: ${title.textContent}\n\nNews Content: ${bodyText}`;
            userInput.value = fullText.substring(0, 11500); // Batasi hingga 11500 karakter

            // Panggil fungsi sendMessage() secara otomatis
            await sendMessage(); // Pastikan untuk menunggu hingga sendMessage selesai
        } else {
            console.error('Title or body not found in the fetched document.'); 
        }
    } catch (error) {
        console.error('Error fetching news:', error); 
        alert('Terjadi kesalahan saat mengambil berita. Cek kembali link berita anda.'); 
    } finally {
        // Menghapus pesan "Sedang Membaca Berita.."
        document.getElementById('loadingMessage').remove();
        toggleFetchNewsButton(true); // Mengaktifkan kembali tombol setelah proses selesai
    }
});

// Fungsi untuk menonaktifkan atau mengaktifkan tombol
function toggleFetchNewsButton(isEnabled) {
    const fetchNewsButton = document.getElementById('fetchNews');
    fetchNewsButton.disabled = !isEnabled; // Menonaktifkan tombol jika isEnabled false
}

async function sendMessage() {
    const userInput = document.getElementById('userInput').value;
    if (!userInput.trim()) {
        alert('Silakan masukkan teks untuk dikirim.');
        return;
    }
    document.getElementById('chatResponse').innerText = 'Analyzing News...';

    try {
        const response = await fetch(`http://localhost:3000/chat?${encodeURIComponent(userInput)}`);
        if (response.ok) {
            const reply = await response.text();
            document.getElementById('chatResponse').innerText = reply;

            // Panggil fungsi convertToBold setelah mendapatkan respon
            convertToBold();

            // Log chat history to console
            console.log('User:', userInput);
            console.log('System:', reply);
        } else {
            console.error('Error fetching chat response:', response.statusText);
            document.getElementById('chatResponse').innerText = 'Error fetching chat response';
        }
    } catch (error) {
        console.error('Error fetching chat response:', error);
        document.getElementById('chatResponse').innerText = 'Error fetching chat response';
    }
}