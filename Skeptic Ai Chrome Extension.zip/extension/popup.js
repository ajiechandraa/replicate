function toggleChatResponse() {
    // ... logika fungsi di sini ...
}

document.getElementById('fetchNews').addEventListener('click', function() {
    document.getElementById('chatResponse').style.display = ''; 
});

function setActiveTabLink() {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        const activeTab = tabs[0];
        if (activeTab) { // Memastikan ada tab aktif
            const newsLinkInput = document.getElementById('newsLink');
            newsLinkInput.value = activeTab.url; // Mengatur nilai input dengan URL tab aktif
            newsLinkInput.setAttribute('value', activeTab.url); // Mengatur atribut value
        }
    });
}

// Panggil fungsi saat popup dibuka
document.addEventListener('DOMContentLoaded', setActiveTabLink);

// ... logika fungsi di sini ...