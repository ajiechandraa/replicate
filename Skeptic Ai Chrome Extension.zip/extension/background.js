chrome.runtime.onInstalled.addListener(() => {
    console.log("Ekstensi terinstal");
});

chrome.action.onClicked.addListener((tab) => {
    chrome.tabs.create({ url: "popup.html" }); 
});
