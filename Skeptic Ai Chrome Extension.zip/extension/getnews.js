// Constants
const CORS_PROXY = 'https://api.codetabs.com/v1/proxy?quest=';
const MAX_INPUT_LENGTH = 11500;

// DOM Elements
const elements = {
    fetchNews: document.getElementById('fetchNews'),
    newsLink: document.getElementById('newsLink'),
    newsDomain: document.getElementById('newsDomain'),
    newsTitle: document.getElementById('newsTitle'),
    newsBody: document.getElementById('newsBody'),
    userInput: document.getElementById('userInput'),
    chatResponse: document.getElementById('chatResponse')
};

// Event Listeners
elements.fetchNews.addEventListener('click', fetchNews);

// Main Functions
async function fetchNews() {
    toggleFetchNewsButton(false);
    const url = elements.newsLink.value;

    if (!url) {
        showAlert('An error occurred while retrieving the news. Refresh your news link.');
        toggleFetchNewsButton(true);
        return;
    }

    console.log('Fetching news from:', url);
    elements.chatResponse.innerText = '🔍 Reading the news';

    try {
        const domain = new URL(url).hostname;
        elements.newsDomain.innerText = domain;

        const text = await fetchUrl(CORS_PROXY + encodeURIComponent(url));
        const { title, bodyText } = parseHtml(text);

        updateNewsElements(title, bodyText);
        updateUserInput(domain, title, bodyText);
        await sendMessage();
    } catch (error) {
        console.error('Error fetching news:', error);
        showAlert('An error occurred while retrieving the news. Refresh your news link.');
    } finally {
        toggleFetchNewsButton(true);
    }
}

async function sendMessage() {
    const userInput = elements.userInput.value.trim();
    if (!userInput) {
        showAlert('An error occurred while retrieving the news. Refresh your news link.');
        return;
    }

    elements.chatResponse.innerText = '✨ Analyzing news...';
    let dotCount = 0;
    const maxDots = 3;
    const interval = setInterval(() => {
        dotCount = (dotCount + 1) % (maxDots + 1);
        elements.chatResponse.innerText = '✨ Analyzing news' + '.'.repeat(dotCount);
    }, 500);

    try {
        const reply = await fetchUrl(`http://localhost:3000/chat?${encodeURIComponent(userInput)}`);
        const trimmedReply = reply.replace(/^\s+/, '');
        elements.chatResponse.innerText = trimmedReply;
        clearInterval(interval); // Stop the animation
        convertToBold();
        console.log('User:', userInput);
        console.log('System:', reply);
    } catch (error) {
        console.error('Error fetching chat response:', error);
        elements.chatResponse.innerText = 'Error fetching chat response';
    }
}

// Helper Functions
function toggleFetchNewsButton(isEnabled) {
    elements.fetchNews.disabled = !isEnabled;
}

function showAlert(message) {
    alert(message);
}

async function fetchUrl(url) {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error('Network response was not ok: ' + response.statusText);
    }
    return response.text();
}

function parseHtml(text) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(text, 'text/html');

    const title = doc.querySelector('title')?.textContent || '';
    const body = doc.querySelector('body');

    if (!body) {
        throw new Error('Body not found in the fetched document.');
    }

    body.querySelectorAll('script, style, [type="application/ld+json"]').forEach(el => el.remove());
    const bodyText = Array.from(body.querySelectorAll('p'))
        .map(p => p.textContent)
        .join(' ')
        .replace(/\s+/g, ' ')
        .trim();

    return { title, bodyText };
}

function updateNewsElements(title, bodyText) {
    elements.newsTitle.innerText = title;
    elements.newsBody.innerText = bodyText;
}

function updateUserInput(domain, title, bodyText) {
    const fullText = `News Domain: ${domain}\n\nNews Title: ${title}\n\nNews Content: ${bodyText}`;
    elements.userInput.value = fullText.substring(0, MAX_INPUT_LENGTH);
}

function convertToBold() {
    const chatResponse = elements.chatResponse;
    const textNodes = chatResponse.childNodes;

    for (let i = 0; i < textNodes.length; i++) {
        const node = textNodes[i];

        if (node.nodeType === Node.TEXT_NODE) {
            const text = node.textContent;
            const regexBold = /\*\*(.*?)\*\*/g;
            const boldText = text.replace(regexBold, '<b>$1</b>');
            const styledText = styleAlert(boldText); 
            const progressText = convertProgress(styledText);
            const boldElement = document.createElement('span');
            boldElement.innerHTML = progressText;

            if (progressText.includes('<div class="alert">')) {
                boldElement.classList.add('alert');
            }

            chatResponse.replaceChild(boldElement, node);
        }
    }
}

function styleAlert(text) {
    text = text.replace(/SKEPTIC LEVEL: LOW/g, '<div class="alert alert-low">SKEPTIC LEVEL: LOW</div>');
    text = text.replace(/SKEPTIC LEVEL: MEDIUM/g, '<div class="alert alert-medium">SKEPTIC LEVEL: MEDIUM</div>');
    text = text.replace(/SKEPTIC LEVEL: HIGH/g, '<div class="alert alert-high">SKEPTIC LEVEL: HIGH</div>');
    
    return text.replace(/##(.*?)##/g, '<div class="alert">$1</div>');
}

function convertProgress(text) {
    const progressRegex = /@@(\d+)\/10@@/g;
    return text.replace(progressRegex, (match, number) => {
        const num = parseInt(number);
        const width = num * 10;
        let barClass = 'plow';
        if (num > 3 && num < 8) {
            barClass = 'pmedium';
        } else if (num >= 8) {
            barClass = 'phigh';
        }
        return `<div class="progress-container"><div class="progress-bar ${barClass}" style="width: ${width}%;"><span class="progress-text">${num}/10</span></div></div>`;
    });
}

// Add stylesheet
const link = document.createElement('link');
link.rel = 'stylesheet';
link.href = 'style.css'; 
document.head.appendChild(link);

