// Menambahkan event listener untuk mengatur interaksi dengan popup
document.addEventListener('DOMContentLoaded', () => {
    // Mengatur komunikasi dengan popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'fetchNews') {
            // Logika untuk mengambil berita atau melakukan tindakan lain
            console.log('Fetching news action received');
            // ... tambahkan logika sesuai kebutuhan ...
        }
    });
});
