document.getElementById('fetchNews').addEventListener('click', async () => {
    // Menonaktifkan tombol setelah diklik
    toggleFetchNewsButton(false);
    
    const url = document.getElementById('newsLink').value;
    if (!url) {
        alert('An error occurred while retrieving the news. Refresh your news link.');
        toggleFetchNewsButton(true); // Mengaktifkan kembali tombol jika URL tidak valid
        return;
    }
    console.log('Fetching news from:', url); 
    const corsProxy = 'https://api.codetabs.com/v1/proxy?quest=';

    // Menampilkan pesan "Sedang Membaca Berita.."
    const loadingMessage = document.createElement('p');
    loadingMessage.id = 'loadingMessage';
    document.body.appendChild(loadingMessage);

    // Menampilkan domain utama di atas headline
    const domain = new URL(url).hostname;
    document.getElementById('newsDomain').innerText = domain;

    // Menambahkan notifikasi sebelum memulai proses pengambilan berita
    document.getElementById('chatResponse').innerText = 'Reading the news...';

    try {
        const response = await fetch(corsProxy + encodeURIComponent(url));
        console.log('Response status:', response.status); 
        if (!response.ok) {
            throw new Error('Network response was not ok: ' + response.statusText);
        }
        const text = await response.text();
        console.log('Fetched text:', text); 
        const parser = new DOMParser();
        const doc = parser.parseFromString(text, 'text/html');

        const title = doc.querySelector('title');
        const body = doc.querySelector('body');

        if (title && body) {
            // Menghapus elemen-elemen yang tidak diinginkan
            body.querySelectorAll('script, style, [type="application/ld+json"]').forEach(el => el.remove());

            // Mengambil teks dari elemen <p>
            const paragraphs = body.querySelectorAll('p');
            let bodyText = '';
            paragraphs.forEach(p => {
                bodyText += p.textContent + ' ';
            });
            bodyText = bodyText.replace(/\n+/g, ' ').trim(); // Menghapus semua baris baru
            bodyText = bodyText.replace(/\s+/g, ' '); // Menghapus spasi ganda

            document.getElementById('newsTitle').innerText = title.textContent;
            document.getElementById('newsBody').innerText = bodyText;
            console.log('News title:', title.textContent); 
            console.log('News body:', bodyText); 

            // Memasukkan semua data ke dalam <textarea id="userInput">
            const userInput = document.getElementById('userInput');
            const fullText = `News Domain: ${domain}\n\nNews Title: ${title.textContent}\n\nNews Content: ${bodyText}`;
            userInput.value = fullText.substring(0, 11500); // Batasi hingga 11500 karakter

            // Panggil fungsi sendMessage() secara otomatis
            await sendMessage(); // Pastikan untuk menunggu hingga sendMessage selesai
        } else {
            console.error('Title or body not found in the fetched document.'); 
        }
    } catch (error) {
        console.error('Error fetching news:', error); 
        alert('An error occurred while retrieving the news. Refresh your news link.'); 
    } finally {
        // Menghapus pesan "Sedang Membaca Berita.."
        document.getElementById('loadingMessage').remove();
        toggleFetchNewsButton(true); // Mengaktifkan kembali tombol setelah proses selesai
    }
});

// Fungsi untuk menonaktifkan atau mengaktifkan tombol
function toggleFetchNewsButton(isEnabled) {
    const fetchNewsButton = document.getElementById('fetchNews');
    fetchNewsButton.disabled = !isEnabled; // Menonaktifkan tombol jika isEnabled false
}

async function sendMessage() {
    const userInput = document.getElementById('userInput').value;
    if (!userInput.trim()) {
        alert('An error occurred while retrieving the news. Refresh your news link.');
        return;
    }
    document.getElementById('chatResponse').innerText = 'Analyzing News...';

    try {
        const response = await fetch(`http://localhost:3000/chat?${encodeURIComponent(userInput)}`);
        if (response.ok) {
            const reply = await response.text();
            // Menghapus spasi atau enter di awal jawaban
            const trimmedReply = reply.replace(/^\s+/, '');
            document.getElementById('chatResponse').innerText = trimmedReply;

            // Panggil fungsi convertToBold setelah mendapatkan respon
            convertToBold();

            // Log chat history to console
            console.log('User:', userInput);
            console.log('System:', reply);
        } else {
            console.error('Error fetching chat response:', response.statusText);
            document.getElementById('chatResponse').innerText = 'Error fetching chat response';
        }
    } catch (error) {
        console.error('Error fetching chat response:', error);
        document.getElementById('chatResponse').innerText = 'Error fetching chat response';
    }
}

function convertToBold() {
    const chatResponse = document.getElementById('chatResponse');
    const textNodes = chatResponse.childNodes;

    for (let i = 0; i < textNodes.length; i++) {
        const node = textNodes[i];

        if (node.nodeType === Node.TEXT_NODE) {
            const text = node.textContent;
            const regexBold = /\*\*(.*?)\*\*/g;
            const boldText = text.replace(regexBold, '<b>$1</b>');
            const convertedText = convert(boldText);
            const styledText = styleAlert(convertedText);
            const boldElement = document.createElement('span');
            boldElement.innerHTML = styledText; // Gunakan styledText

            // Tambahkan kelas CSS jika ada elemen alert
            if (styledText.includes('<div class="alert">')) {
                boldElement.classList.add('alert'); // Menambahkan kelas alert
            }

            chatResponse.replaceChild(boldElement, node);
        }
    }
}

// Fungsi untuk mengonversi tiga dash menjadi garis horizontal
function convert(text) {
    return text.replace(/---/g, '<hr>');
}

// Fungsi untuk menambahkan kelas alert
function styleAlert(text) {
    // Mengganti teks LOW, MEDIUM, HIGH dengan kelas alert yang sesuai
    text = text.replace(/SKEPTIC LEVEL: LOW/g, '<div class="alert alert-low">SKEPTIC LEVEL: LOW</div>');
    text = text.replace(/SKEPTIC LEVEL: MEDIUM/g, '<div class="alert alert-medium">SKEPTIC LEVEL: MEDIUM</div>');
    text = text.replace(/SKEPTIC LEVEL: HIGH/g, '<div class="alert alert-high">SKEPTIC LEVEL: HIGH</div>');
    
    return text.replace(/##(.*?)##/g, '<div class="alert">$1</div>'); 
}

const link = document.createElement('link');
link.rel = 'stylesheet';
link.href = 'style.css'; 
document.head.appendChild(link);
