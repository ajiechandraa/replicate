const http = require('http');
const fs = require('fs');
const Replicate = require('replicate');
require('dotenv').config();
const path = require('path');

// Pastikan token API tersedia
if (!process.env.REPLICATE_API_TOKEN) {
    console.error("Error: REPLICATE_API_TOKEN tidak disetel di lingkungan.");
    process.exit(1);
}

// Buat instance Replicate dengan token otentikasi
const replicate = new Replicate({
    auth: process.env.REPLICATE_API_TOKEN,
});

// Fungsi untuk memproses prompt dan mengirimkannya ke API Replicate
const processPrompt = async (prompt) => {
    const input = {
        top_k: 50,
        top_p: 0.9,
        prompt: prompt,
        max_tokens: 1024,
        min_tokens: 0,
        temperature: 0.6,
        system_prompt: "Anda adalah asisten yang membantu.",
        presence_penalty: 0,
        frequency_penalty: 0
    };

    try {
        // Panggil API Replicate dan stream responsnya
        let response = '';
        for await (const event of replicate.stream("meta/meta-llama-3.1-405b-instruct", { input })) {
            response += event.toString();
        }
        return response;
    } catch (error) {
        console.error("Error:", error);
        return "Terjadi kesalahan saat memproses permintaan.";
    }
};

// Fungsi utama untuk menjalankan server
(async () => {
    const history = [];

    const server = http.createServer(async (request, response) => {
        // Tambahkan header CORS
        response.setHeader("Access-Control-Allow-Origin", "*"); // Mengizinkan semua origin
        response.setHeader("Access-Control-Allow-Methods", "GET, POST"); // Mengizinkan metode yang diperlukan
        response.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization"); // Mengizinkan header yang diperlukan

        const { url } = request;
        if (url === "/health") {
            response.writeHead(200).end("OK");
        } else if (url === "/" || url === "/index.html") {
            const filePath = path.join(__dirname, 'index.html');
            try {
                const data = fs.readFileSync(filePath, 'utf8');
                response.writeHead(200, { "Content-Type": "text/html" });
                response.end(data);
            } catch (err) {
                console.error('File not found:', err);
                response.writeHead(404, { "Content-Type": "text/plain" });
                response.end('404 Not Found');
            }
        } else if (url.startsWith("/chat")) {
            const parsedUrl = new URL(`http://localhost${url}`);
            const { search } = parsedUrl;
            const inquiry = decodeURIComponent(search.substring(1));
            response.writeHead(200, { "Content-Type": "text/plain" });

            // Log inquiry to terminal
            console.log('User:', inquiry);

            const answer = await processPrompt(inquiry);

            // Log answer to terminal with an extra newline for separation
            console.log('System:', answer, '\n');

            history.push({ inquiry, answer });

            response.end(answer); // Kirimkan jawaban sebagai respons
        } else {
            console.error(`${url} is 404!`);
            response.writeHead(404);
            response.end();
        }
    });

    const port = process.env.PORT || 3000;
    server.listen(port);
    console.log("Listening on port", port);
})();