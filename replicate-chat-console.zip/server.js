const Replicate = require('replicate');
require('dotenv').config();
const readline = require('readline');

// Pastikan token API tersedia
if (!process.env.REPLICATE_API_TOKEN) {
    console.error("Error: REPLICATE_API_TOKEN tidak disetel di lingkungan.");
    process.exit(1);
}

// Atur readline untuk input pengguna dari terminal
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Buat instance Replicate dengan token otentikasi
const replicate = new Replicate({
    auth: process.env.REPLICATE_API_TOKEN,
});

// Fungsi untuk memproses input pengguna dan mengirimkannya ke API Replicate
const askQuestion = (query) => {
    return new Promise((resolve) => rl.question(query, resolve));
};

// Fungsi untuk memproses prompt dan mengirimkannya ke API Replicate
const processPrompt = async (prompt) => {
    const input = {
        top_k: 50,
        top_p: 0.9,
        prompt: prompt,
        max_tokens: 1024,
        min_tokens: 0,
        temperature: 0.6,
        system_prompt: "Anda adalah asisten yang membantu.",
        presence_penalty: 0,
        frequency_penalty: 0
    };

    try {
        // Panggil API Replicate dan stream responsnya
        process.stdout.write("Bot: ");
        for await (const event of replicate.stream("meta/meta-llama-3.1-405b-instruct", { input })) {
            process.stdout.write(event.toString());
        }
        console.log(); // Tambahkan baris baru setelah respons
    } catch (error) {
        console.error("Error:", error);
    }
};

// Fungsi utama
const main = async () => {
    while (true) {
        const prompt = await askQuestion("Chat: ");
        if (prompt.toLowerCase() === 'exit') {  // Ketik exit untuk keluar
            break;
        }
        await processPrompt(prompt);
    }
    rl.close(); // Tutup antarmuka readline
};

// Jalankan fungsi utama
main();