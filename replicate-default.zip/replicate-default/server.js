const Replicate = require('replicate');
require('dotenv').config();
const readline = require('readline');

// Ensure the API token is available
if (!process.env.REPLICATE_API_TOKEN) {
    console.error("Error: REPLICATE_API_TOKEN is not set in the environment.");
    process.exit(1);
}

// Set up readline for user input from the terminal
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Create a Replicate instance with authentication token
const replicate = new Replicate({
    auth: process.env.REPLICATE_API_TOKEN,
});

// Function to process user input and send it to Replicate API
const askQuestion = (query) => {
    return new Promise((resolve) => rl.question(query, resolve));
};

// Main function
const main = async () => {
    // Ask the user to input a prompt
    const prompt = await askQuestion("Enter your prompt: ");

    const input = {
        top_k: 50,
        top_p: 0.9,
        prompt: prompt,
        max_tokens: 1024,
        min_tokens: 0,
        temperature: 0.6,
        system_prompt: "You are a helpful assistant.",
        presence_penalty: 0,
        frequency_penalty: 0
    };

    // Call the Replicate API and stream the response
    try {
        for await (const event of replicate.stream("meta/meta-llama-3.1-405b-instruct", { input })) {
            process.stdout.write(event.toString());
        }
    } catch (error) {
        console.error("Error:", error);
    } finally {
        rl.close(); // Close the readline interface
    }
};

// Execute the main function
main();
